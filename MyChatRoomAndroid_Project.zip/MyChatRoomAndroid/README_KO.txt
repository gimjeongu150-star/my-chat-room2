나만의 대화방 - Android Studio 프로젝트

중요:
이 ZIP은 APK 파일 자체가 아니라 APK를 빌드할 수 있는 Android Studio 프로젝트입니다.
현재 제작 환경에는 Android SDK/Gradle 빌드 환경이 없어 여기서 APK를 직접 컴파일하지 못했습니다.

APK 빌드 방법:
1. PC에 Android Studio를 설치합니다.
2. Android Studio에서 이 압축을 푼 MyChatRoom 폴더를 엽니다.
3. Gradle 동기화가 끝날 때까지 기다립니다. Android SDK Platform 35 설치를 요청하면 설치합니다.
4. 메뉴에서 Build > Build Bundle(s) / APK(s) > Build APK(s)를 선택합니다.
5. 빌드가 완료되면 app/build/outputs/apk/debug/app-debug.apk 파일을 찾습니다.
6. APK를 안드로이드 휴대폰으로 옮겨 설치합니다. 휴대폰 설정에서 해당 앱/파일 관리자의 앱 설치 권한을 허용해야 할 수 있습니다.

기능:
- 오프라인 HTML 기반 대화 UI
- 캐릭터 A/B 선택 및 상황 묘사
- 캐릭터 이름과 이미지 URL 설정
- 대화 추가, 수정, 삭제, JSON 내보내기
- WebView의 로컬 저장소에 대화 저장

주의:
- 대화는 앱 내부 WebView 저장소에 저장됩니다. 앱 데이터 삭제 또는 앱 제거 시 사라질 수 있습니다.
- 프로필 이미지 URL은 온라인 이미지 주소일 때만 로드될 수 있습니다.
- 이 프로젝트는 서명된 배포용 APK가 아니라 로컬 테스트용 debug APK를 만드는 구성입니다.
